-- {{TITLE}} --
select 1 from dual;